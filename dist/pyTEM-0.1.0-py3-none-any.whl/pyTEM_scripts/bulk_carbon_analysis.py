

def bulk_carbon_analysis():
    """

    :return:
    """
    raise NotImplementedError


if __name__ == "__main__":
    bulk_carbon_analysis()
